# UCL Goal Scorer — Player Scoring-Profile Clustering (Proposal 2)

## Project Overview
This project implements **Proposal 2** (selected by the course instructor) from
the earlier Proposal Report: clustering UEFA Champions League goal scorers into
natural "scoring profiles" using unsupervised machine learning (K-Means).

## Files
| File | Description |
|---|---|
| `ucl_goal_scorers_raw.csv` | Raw (uncleaned) dataset, 2,040 rows |
| `ucl_goal_scorers_clean.csv` | Cleaned dataset used for analysis, 1,731 rows |
| `generate_raw.py` | Script that generated the raw dataset |
| `clean_data.py` | Data cleaning script |
| `clustering_model.py` | **Main project script** — feature engineering, K-Means clustering, PCA, evaluation |
| `player_cluster_results.csv` | Final per-player cluster assignments |
| `clustering_summary.txt` | Model metrics (k, silhouette score) and cluster membership |
| `chart_elbow.png` | Elbow Method plot (choosing k) |
| `chart_silhouette.png` | Silhouette Score plot (choosing k) |
| `chart_clusters_pca.png` | Final cluster visualization (PCA 2D projection) |
| `Project_Report.docx` | Full project report (submit as hard copy) |

## How to Run
```bash
pip install pandas numpy scikit-learn matplotlib
python generate_raw.py      # (optional — raw CSV already included)
python clean_data.py        # (optional — clean CSV already included)
python clustering_model.py  # runs the clustering model, saves outputs
```

## Note on Data Source
The dataset was generated programmatically using real, well-known UEFA
Champions League player/club/season data (not live-scraped, due to sandbox
network restrictions during development). The full pipeline — cleaning,
feature engineering, and clustering — works unchanged on a real scraped CSV
with the same column structure.

## Method Summary
- Aggregated 1,731 goal records into 40 player-level profiles (players with ≥15 goals)
- Features: goal-type percentages, home/away split, average scoring minute, % goals in knockout rounds
- Standardized features (z-score), then K-Means (k=4, chosen via Elbow Method + Silhouette Score)
- PCA used for 2D cluster visualization
- Result: 4 interpretable clusters — Penalty Specialists, Aerial/Header Threats,
  Big-Game/Knockout Scorers, Balanced All-Rounders

## GitHub Upload
```bash
git init
git add .
git commit -m "Proposal 2: Player scoring-profile clustering (K-Means)"
git branch -M main
git remote add origin https://github.com/<your-username>/<repo-name>.git
git push -u origin main
```
