import pandas as pd
import numpy as np

df = pd.read_csv("ucl_goal_scorers_raw.csv")

str_cols = df.select_dtypes(include="object").columns
for c in str_cols:
    df[c] = df[c].astype(str).str.strip()
    df[c] = df[c].replace({"nan": np.nan, "None": np.nan, "": np.nan})

for c in ["Player", "Club", "Opponent", "Nationality"]:
    df[c] = df[c].str.title()

df["Round"] = df["Round"].str.title().replace({"R16": "Round Of 16"})
df["Goal_Type"] = df["Goal_Type"].str.title()
df["Venue"] = df["Venue"].str.title()

df["Minute"] = df["Minute"].astype(str).str.replace("'", "", regex=False)
df["Minute"] = pd.to_numeric(df["Minute"], errors="coerce")

df = df[df["Opponent"] != df["Club"]]
df = df.dropna(subset=["Opponent"])

median_minute = df["Minute"].median()
df["Minute"] = df["Minute"].fillna(median_minute)
df["Minute"] = df["Minute"].astype(int)

nat_map = df.dropna(subset=["Nationality"]).groupby("Player")["Nationality"].agg(lambda x: x.mode()[0])
df["Nationality"] = df.apply(
    lambda r: nat_map.get(r["Player"], r["Nationality"]) if pd.isna(r["Nationality"]) else r["Nationality"],
    axis=1
)

df = df.drop_duplicates()
df = df[(df["Minute"] >= 1) & (df["Minute"] <= 96)]

df["Goals_In_Match"] = pd.to_numeric(df["Goals_In_Match"], errors="coerce")
df = df.dropna(subset=["Goals_In_Match"])
df["Goals_In_Match"] = df["Goals_In_Match"].astype(int)

df = df.reset_index(drop=True)
df.to_csv("ucl_goal_scorers_clean.csv", index=False)
print(f"Clean rows: {len(df)}")
