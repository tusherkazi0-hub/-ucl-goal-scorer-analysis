import pandas as pd
import numpy as np
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
from sklearn.preprocessing import StandardScaler
from sklearn.cluster import KMeans
from sklearn.decomposition import PCA
from sklearn.metrics import silhouette_score

plt.rcParams["figure.dpi"] = 150
df = pd.read_csv("ucl_goal_scorers_clean.csv")

# ---------- 1. Feature Engineering: aggregate to one row per player ----------
knockout_rounds = ["Round Of 16", "Quarter-Final", "Semi-Final", "Final"]

def player_features(g):
    total_goals = len(g)
    gt = g["Goal_Type"].value_counts(normalize=True)
    return pd.Series({
        "Total_Goals": total_goals,
        "Pct_Penalty": gt.get("Penalty", 0) * 100,
        "Pct_Header": gt.get("Header", 0) * 100,
        "Pct_Right_Foot": gt.get("Right Foot", 0) * 100,
        "Pct_Left_Foot": gt.get("Left Foot", 0) * 100,
        "Pct_Free_Kick": gt.get("Free Kick", 0) * 100,
        "Pct_Home": (g["Venue"] == "Home").mean() * 100,
        "Avg_Minute": g["Minute"].mean(),
        "Pct_Knockout": g["Round"].isin(knockout_rounds).mean() * 100,
    })

player_df = df.groupby("Player").apply(player_features, include_groups=False).reset_index()

# Keep only players with a reasonable sample size for stable percentages
MIN_GOALS = 15
player_df = player_df[player_df["Total_Goals"] >= MIN_GOALS].reset_index(drop=True)
print(f"Players included in clustering (>= {MIN_GOALS} goals): {len(player_df)}")

feature_cols = ["Pct_Penalty", "Pct_Header", "Pct_Right_Foot", "Pct_Left_Foot",
                 "Pct_Free_Kick", "Pct_Home", "Avg_Minute", "Pct_Knockout"]
X = player_df[feature_cols].values

# ---------- 2. Standardization ----------
scaler = StandardScaler()
X_scaled = scaler.fit_transform(X)

# ---------- 3. Elbow Method + Silhouette Score to choose k ----------
inertias = []
sil_scores = []
k_range = range(2, 8)
for k in k_range:
    km = KMeans(n_clusters=k, random_state=42, n_init=10)
    labels = km.fit_predict(X_scaled)
    inertias.append(km.inertia_)
    sil_scores.append(silhouette_score(X_scaled, labels))

plt.figure(figsize=(8, 5))
plt.plot(list(k_range), inertias, marker="o", color="#1f4e8c")
plt.title("Elbow Method for Optimal k")
plt.xlabel("Number of Clusters (k)")
plt.ylabel("Inertia")
plt.tight_layout()
plt.savefig("chart_elbow.png")
plt.close()

plt.figure(figsize=(8, 5))
plt.plot(list(k_range), sil_scores, marker="o", color="#27ae60")
plt.title("Silhouette Score by k")
plt.xlabel("Number of Clusters (k)")
plt.ylabel("Silhouette Score")
plt.tight_layout()
plt.savefig("chart_silhouette.png")
plt.close()

best_k = list(k_range)[int(np.argmax(sil_scores))]
print("Silhouette scores:", dict(zip(k_range, [round(s, 3) for s in sil_scores])))
print(f"Chosen k (best silhouette): {best_k}")

# ---------- 4. Final K-Means model ----------
K = 4 if 4 in k_range else best_k  # use k=4 as planned in proposal, matches typical elbow point
kmeans = KMeans(n_clusters=K, random_state=42, n_init=10)
player_df["Cluster"] = kmeans.fit_predict(X_scaled)
final_sil = silhouette_score(X_scaled, player_df["Cluster"])
print(f"Final model k={K}, Silhouette Score={final_sil:.3f}")

# ---------- 5. PCA for 2D visualization ----------
pca = PCA(n_components=2, random_state=42)
coords = pca.fit_transform(X_scaled)
player_df["PC1"] = coords[:, 0]
player_df["PC2"] = coords[:, 1]
explained_var = pca.explained_variance_ratio_
print(f"PCA explained variance: PC1={explained_var[0]:.2%}, PC2={explained_var[1]:.2%}")

# ---------- 6. Interpret & label clusters based on feature means ----------
cluster_profile = player_df.groupby("Cluster")[feature_cols + ["Total_Goals"]].mean().round(1)
print("\nCluster feature means:\n", cluster_profile)

def label_cluster(row):
    if row["Pct_Penalty"] == cluster_profile["Pct_Penalty"].max():
        return "Penalty Specialists"
    if row["Pct_Header"] == cluster_profile["Pct_Header"].max():
        return "Aerial / Header Threats"
    if row["Pct_Knockout"] == cluster_profile["Pct_Knockout"].max():
        return "Big-Game / Knockout Scorers"
    return "Balanced All-Rounders"

cluster_labels = {c: label_cluster(cluster_profile.loc[c]) for c in cluster_profile.index}
player_df["Cluster_Label"] = player_df["Cluster"].map(cluster_labels)
print("\nCluster labels:", cluster_labels)

# ---------- 7. Visualization: PCA scatter plot with cluster labels ----------
plt.figure(figsize=(9, 7))
colors = ["#1f4e8c", "#c0392b", "#27ae60", "#f39c12", "#8e44ad", "#16a085"]
for c in sorted(player_df["Cluster"].unique()):
    sub = player_df[player_df["Cluster"] == c]
    plt.scatter(sub["PC1"], sub["PC2"], s=90, color=colors[c % len(colors)],
                label=f"Cluster {c}: {cluster_labels[c]}", edgecolor="white", linewidth=0.6)
    for _, r in sub.iterrows():
        plt.annotate(r["Player"], (r["PC1"], r["PC2"]), fontsize=7, alpha=0.8,
                     xytext=(4, 4), textcoords="offset points")

plt.title("Player Scoring-Profile Clusters (PCA 2D Projection)")
plt.xlabel(f"PC1 ({explained_var[0]:.1%} variance)")
plt.ylabel(f"PC2 ({explained_var[1]:.1%} variance)")
plt.legend(loc="best", fontsize=8)
plt.tight_layout()
plt.savefig("chart_clusters_pca.png")
plt.close()

# ---------- 8. Save outputs ----------
player_df_sorted = player_df.sort_values(["Cluster", "Total_Goals"], ascending=[True, False])
player_df_sorted.to_csv("player_cluster_results.csv", index=False)

with open("clustering_summary.txt", "w") as f:
    f.write(f"Players included (>= {MIN_GOALS} goals): {len(player_df)}\n")
    f.write(f"Chosen k = {K}\n")
    f.write(f"Silhouette Score = {final_sil:.3f}\n")
    f.write(f"PCA explained variance: PC1={explained_var[0]:.2%}, PC2={explained_var[1]:.2%}\n\n")
    f.write("Cluster feature means:\n")
    f.write(cluster_profile.to_string())
    f.write("\n\nCluster labels:\n")
    for c, lbl in cluster_labels.items():
        members = player_df_sorted[player_df_sorted["Cluster"] == c]["Player"].tolist()
        f.write(f"Cluster {c} - {lbl}: {members}\n")

print("\nAll outputs saved: player_cluster_results.csv, clustering_summary.txt, charts.")
